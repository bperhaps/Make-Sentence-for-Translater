Make sentence for translator
============================

This program is Chrome extenstion.
You can install it from [here](https://chrome.google.com/webstore/detail/make-sentence-for-transla/emlmmgcgnglgamlijmgmnlnkohbipkoi?hl=ko)

Introduce
---------

When you try to translate a PDF document (such as a thesis..) with a translator, a mistranslation occurs due to line breaks.
To solve this, we need to reconnect the broken sentences.
This extension does this automatically.

Supported translators: [Google Translator](https://translate.google.com), [Naver Papago](https://papago.naver.com)

## How to use :
There are two methods of use: manual and automatic.

=Manual=

Paste the sentence into Google Translator or Naver Papago and press Ctrl + q.

=Auto=

Tap the icon on the top right to turn on the switch, and as soon as you paste the sentence into the translator, you can connect the sentence automatically.

