document.onkeydown = (e) => {
    if(e.ctrlKey && e.which == 81) {
        reform();
    }
}
